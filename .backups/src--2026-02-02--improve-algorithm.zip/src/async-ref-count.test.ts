import { describe, expect, it } from 'vitest';
import { TestTools } from '../fabrique/test/tools.ts';
import { AsyncRefCount } from './async-ref-count.ts';
import type { DerivedClosableValue } from './types/derived/derived-closable-value.ts';

describe('AsyncRefCount', () => {
  it('should share a value', async () => {
    let opened: number = 0;
    let closed: number = 0;

    const factory = new AsyncRefCount(() => {
      opened++;

      return {
        value: 42,
        close: async () => {
          closed++;
        },
      };
    });

    expect(opened).toBe(0);
    expect(closed).toBe(0);

    const sharedA = await factory.open();
    expect(sharedA.value).toBe(42);
    expect(opened).toBe(1);
    expect(closed).toBe(0);

    const sharedB = await factory.open();
    expect(sharedB.value).toBe(42);
    expect(opened).toBe(1);
    expect(closed).toBe(0);

    await sharedB.close();
    expect(opened).toBe(1);
    expect(closed).toBe(0);

    await sharedA.close();
    expect(opened).toBe(1);
    expect(closed).toBe(1);

    const sharedC = await factory.open();
    expect(sharedC.value).toBe(42);
    expect(opened).toBe(2);
    expect(closed).toBe(1);
  });

  it('should handle errors while opening', async () => {
    let opened: number = 0;
    let openSignal: AbortSignal | undefined;

    const factory = new AsyncRefCount((signal: AbortSignal) => {
      opened++;
      openSignal = signal;

      throw 'error';
    });

    expect(opened).toBe(0);
    expect(openSignal).toBe(undefined);

    await expect(factory.open()).rejects.toThrow('error');
    expect(opened).toBe(1);
    expect(openSignal).toBeDefined();
    expect(openSignal!.aborted).toBe(true);
  });

  it('should handle abortion while opening', async () => {
    let opened: number = 0;
    let closed: number = 0;

    const factory = new AsyncRefCount(async (signal: AbortSignal) => {
      opened++;

      await TestTools.sleep(100, signal);

      return {
        value: 42,
        close: async () => {
          closed++;
        },
      };
    });

    expect(opened).toBe(0);
    expect(closed).toBe(0);

    const controller = new AbortController();

    setTimeout(() => controller.abort('error'), 50);

    const results = await Promise.allSettled([
      factory.open(),
      factory.open({ signal: controller.signal }),
    ]);

    expect(results[0].status).toBe('fulfilled');
    expect((results[0] as PromiseFulfilledResult<DerivedClosableValue<number>>).value.value).toBe(
      42,
    );
    expect(results[1].status).toBe('rejected');
    expect((results[1] as PromiseRejectedResult).reason).toBe('error');

    expect(opened).toBe(1);
    expect(closed).toBe(0);
  });

  it('should await closing any previous task while opening', async () => {
    let opened: number = 0;
    let closing: number = 0;
    let closed: number = 0;

    const factory = new AsyncRefCount(async (signal: AbortSignal) => {
      console.log('open');
      opened++;

      return {
        value: 42,
        close: async () => {
          closing++;
          await TestTools.sleep(100, signal);
          closed++;
          console.log('closed');
        },
      };
    });

    expect(opened).toBe(0);
    expect(closing).toBe(0);
    expect(closed).toBe(0);

    const sharedA = await factory.open();
    expect(sharedA.value).toBe(42);
    expect(opened).toBe(1);
    expect(closing).toBe(0);
    expect(closed).toBe(0);

    const sharedAClosePromise = sharedA.close();
    expect(closing).toBe(1);
    expect(closed).toBe(0);

    const sharedBOpenPromise = factory.open();
    expect(opened).toBe(1);

    const sharedB = await sharedBOpenPromise;
    console.log('opened');
    expect(sharedB.value).toBe(42);
    expect(opened).toBe(2);
    expect(closing).toBe(1);
    expect(closed).toBe(1);

    await sharedAClosePromise;
  });

  it('should prevent closing a derived value more than one time', async () => {
    const factory = new AsyncRefCount(() => {
      return {
        value: 42,
        close: () => {},
      };
    });

    const shared = await factory.open();

    await expect(shared.close()).resolves.toBeUndefined();
    await expect(shared.close()).rejects.toThrow();
  });
});
