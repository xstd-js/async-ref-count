import { type Abortable, abortify } from '@xstd/abortable';
import type { ClosableValue } from './types/closable-value.ts';
import type { CloseClosableValue } from './types/close-closable-value.ts';
import type { CloseHook } from './types/close-hook.ts';
import type { DerivedClosableValue } from './types/derived/derived-closable-value.ts';
import type { OpenClosableValue } from './types/open-closable-value.ts';

// export class AbortablePromise<GValue> extends Promise<GValue> {
//   constructor(executor: (resolve: (value: GValue) => void, reject: (reason: unknown) => void) => void, abortSignal: AbortSignal) {
//     super((resolve, reject) => {
//       abortSignal.addEventListener('abort', () => reject(new DOMException('Aborted', 'AbortError')));
//       executor(resolve, reject);
//     });
//   }
// }

// export class AbortablePromise<GValue> {
//   constructor(executor: (signal: AbortSignal) => Promise<GValue>) {
//     super((resolve, reject) => {
//       abortSignal.addEventListener('abort', () => reject(new DOMException('Aborted', 'AbortError')));
//       executor(resolve, reject);
//     });
//   }
// }

/**
 * An async reference counter used to open a resource only once and share it multiple times.
 */
export class AsyncRefCount<GValue> {
  readonly #open: OpenClosableValue<GValue>;

  #count: number;
  #openPromise: AbortablePromise<ClosableValue<GValue>> | undefined;
  #closePromise: AbortablePromise<void> | undefined;

  constructor(open: OpenClosableValue<GValue>) {
    this.#open = open;
    this.#count = 0;
  }

  #close(close: CloseClosableValue, reason: unknown): Promise<void> {
    let hookPromise: Promise<void> | undefined;

    const controller: AbortController = new AbortController();
    const signal: AbortSignal = controller.signal;

    const closePromise: Promise<void> = Promise.try(close, reason, (): CloseHook => {
      if (hookPromise !== undefined) {
        throw new Error('Close hook locked.');
      }
      const { promise, resolve, reject } = Promise.withResolvers<void>();
      hookPromise = promise;
      return {
        resolve,
        reject,
        signal,
      };
    });

    const end = (): void => {
      this.#openPromise = undefined;
      this.#closePromise = undefined;
    };

    this.#closePromise = {
      promise:
        hookPromise === undefined
          ? closePromise.then(end, end)
          : hookPromise.then(end, (error: unknown): void => {
              if (signal.aborted || error !== signal.reason) {
                this.#openPromise = undefined;
                reportError(error);
              }
              this.#closePromise = undefined;
            }),
      controller,
    };

    return closePromise;
  }

  // #close(close: CloseClosableValue, reason: unknown): Promise<void> {
  //   this.#closeController = new AbortController();
  //   const signal: AbortSignal = this.#closeController.signal;
  //
  //   let hookPromise: Promise<void> | undefined;
  //
  //   const closePromise: Promise<void> = Promise.try(close, reason, (): CloseHook => {
  //     if (hookPromise !== undefined) {
  //       throw new Error('Close hook locked.');
  //     }
  //     const { promise, resolve, reject } = Promise.withResolvers<void>();
  //     hookPromise = promise;
  //     return {
  //       resolve,
  //       reject,
  //       signal,
  //     };
  //   });
  //
  //   if (hookPromise === undefined) {
  //     hookPromise = closePromise.catch((): void => {});
  //   } else {
  //     hookPromise = hookPromise.catch((error: unknown): void => {
  //       if (!signal.aborted || error !== signal.reason) {
  //         reportError(error);
  //       }
  //     });
  //   }
  //
  //   this.#closePromise = hookPromise.finally((): void => {
  //     console.log('finally');
  //     if (!signal.aborted) {
  //       this.#openPromise = undefined;
  //     }
  //     this.#closeController = undefined;
  //     this.#closePromise = undefined;
  //   });
  //
  //   return closePromise;
  // }

  async open({ signal }: Abortable = {}): Promise<DerivedClosableValue<GValue>> {
    signal?.throwIfAborted();

    if (this.#closePromise !== undefined) {
      this.#closePromise.controller.abort();
      await abortify(this.#closePromise.promise, { signal });
    }

    this.#count++;

    if (this.#openPromise === undefined) {
      const controller: AbortController = new AbortController();
      const signal: AbortSignal = controller.signal;
      this.#openPromise = {
        promise: Promise.try(this.#open, signal),
        controller,
      };
    }

    return new Promise<DerivedClosableValue<GValue>>(
      (
        resolve: (value: DerivedClosableValue<GValue>) => void,
        reject: (reason?: any) => void,
      ): void => {
        const { promise: openPromise, controller: openController } = this.#openPromise!;
        const openSignal: AbortSignal = openController.signal;

        openPromise.then(
          ({ value, close }: ClosableValue<GValue>): void => {
            signal?.removeEventListener('abort', onAbort);

            if (openSignal.aborted) {
              console.warn("open's signal aborted but the promise resolved");

              if (!signal?.aborted) {
                this.#count--;
              }

              if (this.#count === 0) {
                this.#close(close, openSignal.reason).then(
                  (): void => {
                    reject(openSignal.reason);
                  },
                  (error: unknown): void => {
                    reject(new SuppressedError(error, openSignal.reason));
                  },
                );
              } else {
                reject(openSignal.reason);
              }
            } else {
              if (signal?.aborted) {
                reject(signal!.reason);
              } else {
                let closed: boolean = false;

                resolve({
                  value,
                  close: async (reason?: unknown): Promise<void> => {
                    if (closed) {
                      throw new Error('Already closed.');
                    }
                    closed = true;

                    this.#count--;

                    if (this.#count === 0) {
                      await this.#close(close, reason);
                    }
                  },
                });
              }
            }
          },
          (error: unknown): void => {
            signal?.removeEventListener('abort', onAbort);

            if (!signal?.aborted) {
              this.#count--;
            }

            reject(error);
          },
        );

        const onAbort = (): void => {
          this.#count--;

          if (this.#count === 0) {
            openController.abort(signal!.reason);
          } else {
            reject(signal!.reason);
          }
        };

        signal?.addEventListener('abort', onAbort);
      },
    );

    // try {
    //   const { value, close }: ClosableValue<GValue> = await abortify(this.#openPromise!.promise, {
    //     signal,
    //   });
    //
    //   let closed: boolean = false;
    //
    //   return {
    //     value,
    //     close: async (reason?: unknown): Promise<void> => {
    //       if (closed) {
    //         throw new Error('Already closed.');
    //       }
    //       closed = true;
    //
    //       this.#count--;
    //
    //       if (this.#count === 0) {
    //         await this.#close(close, reason);
    //       }
    //     },
    //   };
    // } catch (error: unknown) {
    //   try {
    //     // => failed to open shared resource OR signal aborted
    //     this.#count--;
    //
    //     if (this.#count === 0) {
    //       this.#openPromise!.controller.abort(error);
    //       // safeguard: if `openPromise` fulfills (however, rejection is expected), we close it immediately
    //       await this.#close((await this.#openPromise).close, error);
    //     }
    //   } finally {
    //     throw error;
    //   }
    // }

    // const { promise: openPromise, controller: openController } = this.#openPromise!;
    // const openSignal: AbortSignal = openController.signal;
    //
    // const untilOpened: Promise<DerivedClosableValue<GValue>> = openPromise.then(
    //   ({
    //     value,
    //     close,
    //   }: ClosableValue<GValue>):
    //     | Promise<DerivedClosableValue<GValue>>
    //     | DerivedClosableValue<GValue> => {
    //     if (openSignal.aborted) {
    //       this.#count--;
    //       return this.#close(close, openSignal.reason).then(
    //         (): never => {
    //           throw openSignal.reason;
    //         },
    //         (error: unknown): never => {
    //           throw new SuppressedError(error, openSignal.reason);
    //         },
    //       );
    //     } else {
    //       let closed: boolean = false;
    //
    //       return {
    //         value,
    //         close: async (reason?: unknown): Promise<void> => {
    //           if (closed) {
    //             throw new Error('Already closed.');
    //           }
    //           closed = true;
    //
    //           this.#count--;
    //
    //           if (this.#count === 0) {
    //             await this.#close(close, reason);
    //           }
    //         },
    //       };
    //     }
    //   },
    //   (error: unknown): never => {
    //     this.#count--;
    //     throw error;
    //   },
    // );
    //
    // const { promise: untilAborted, reject: rejectUntilAborted } = Promise.withResolvers();
    //
    // const onAbort = (): void => {
    //   this.#count--;
    //   rejectUntilAborted(signal.reason);
    // };
    //
    // signal.addEventListener('abort', onAbort);
    //
    //
    // Promise.race([untilOpened, untilAborted]);
    //

    // try {
    //   const { value, close }: ClosableValue<GValue> = await abortify(this.#openPromise, {
    //     signal,
    //   });
    //
    //   let closed: boolean = false;
    //
    //   return {
    //     value,
    //     close: async (reason?: unknown): Promise<void> => {
    //       if (closed) {
    //         throw new Error('Already closed.');
    //       }
    //       closed = true;
    //
    //       this.#count--;
    //
    //       if (this.#count === 0) {
    //         await this.#close(close, reason);
    //       }
    //     },
    //   };
    // } catch (error: unknown) {
    //   try {
    //     // => failed to open shared resource OR signal aborted
    //     this.#count--;
    //
    //     if (this.#count === 0) {
    //       this.#openController?.abort(error);
    //       // safeguard: if `openPromise` fulfills (however, rejection is expected), we close it immediately
    //       await this.#close((await this.#openPromise).close, error);
    //     }
    //   } finally {
    //     throw error;
    //   }
    // }
  }
}

/* INTERNAL */

interface AbortablePromise<GValue> {
  readonly promise: Promise<GValue>;
  readonly controller: AbortController;
}

function abortablePromise<GValue>(
  factory: (signal: AbortSignal) => PromiseLike<GValue> | GValue,
): AbortablePromise<GValue> {
  const controller: AbortController = new AbortController();
  return {
    promise: Promise.try(factory, controller.signal).finally((): void => {
      controller.abort();
    }),
    controller,
  };
}

/*-----------*/

export class SharedClosableResource<GValue> {
  readonly #open: OpenClosableValue<GValue>;
}
