import type { CloseHook } from './close-hook.ts';

/**
 * Acquires a hook on a closing ClosableValue:
 *
 * @returns {CloseHook} A hook on the closing process.
 */
export interface AcquireCloseHook {
  (): CloseHook;
}
