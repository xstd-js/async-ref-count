import type { CloseClosableValue } from './close-closable-value.ts';

/**
 * A value that can be "closed".
 */
export interface ClosableValue<GValue> {
  /**
   * An abstract linked to this "close" operation.
   */
  readonly value: GValue;

  /**
   * A function to "close" the value.
   */
  readonly close: CloseClosableValue;
}
