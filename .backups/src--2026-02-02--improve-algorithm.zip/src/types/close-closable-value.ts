import type { AcquireCloseHook } from './acquire-close-hook.ts';

/**
 * Closes a `ClosableValue`.
 *
 * @param {unknown} reason - The reason why the value is closed.
 * @param {AcquireCloseHook} hook - A function to acquire a hook on the closing process.
 *  The hook must be called before the current function returns, else an error is thrown.
 * @returns {PromiseLike<void> | void} A promise resolved when the ClosableValue is closed.
 */
export interface CloseClosableValue {
  (reason: unknown, hook: AcquireCloseHook): PromiseLike<void> | void;
}
