/**
 * A "close" hook allows us to dissociate the "close" Promise returned by the `CloseClosableValue` from the one that truly closes the value.
 *
 * If a hook exists while it is not already resolved, calling the "open" method triggers the hook's "signal.abort()" and waits until it resolves.
 * During this process, if the hook rejects with the signal's reason, the previous "open" method is used instead of opening a new one.
 *
 * It exposes the following properties:
 *
 * - `resolve`: a function to resolve the hook's Promise
 * - `reject`: a function to reject the hook's Promise
 * - `signal`: an `AbortSignal` called when the "open" method is called while the hook is still active.
 *    It may be used to cancel the true closing process, as "open" has been called again while closing was not started or finished yet.
 */
export interface CloseHook extends Pick<PromiseWithResolvers<any>, 'resolve' | 'reject'> {
  readonly signal: AbortSignal;
}
