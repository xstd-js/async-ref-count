/**
 * Closes a derived "closable" value.
 */
export interface CloseDerivedClosableValue {
  (reason?: unknown): Promise<void>;
}
