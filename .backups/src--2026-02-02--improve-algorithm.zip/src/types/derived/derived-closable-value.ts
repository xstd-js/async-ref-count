import type { CloseDerivedClosableValue } from './close-derived-closable-value.ts';

/**
 * A "closable" value derived from another one.
 */
export interface DerivedClosableValue<GValue> {
  /**
   * An abstract linked to this "close" operation.
   */
  readonly value: GValue;

  /**
   * A function to "close" this derived "closable" value
   */
  readonly close: CloseDerivedClosableValue;
}
