import type { ClosableValue } from './closable-value.ts';

/**
 * Opens a "closable" value.
 *
 * @param {AbortSignal} signal - An optional signal to abort the opening process
 * @returns {PromiseLike<ClosableValue<GValue>> | ClosableValue<GValue>} A promise of a `ClosableValue` or directly a `ClosableValue`.
 */
export interface OpenClosableValue<GValue> {
  (signal: AbortSignal): PromiseLike<ClosableValue<GValue>> | ClosableValue<GValue>;
}
